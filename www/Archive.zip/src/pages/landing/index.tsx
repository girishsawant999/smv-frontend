import React from "react";
import LandingPage from "../../components/containers/landing";
import SlidingRectangle from "../../components/containers/SlidingRectangle/SlidingRectangle";

function Landing(props){
  return <LandingPage/>
}

export default Landing