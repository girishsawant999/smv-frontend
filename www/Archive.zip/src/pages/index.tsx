const Welcome = () => {
  return (
    <div>
      <div className="text-gray-500">Welcome to SMV. Test page to verify setup works</div>
    </div>
  );
};
export default Welcome;
