import Login from 'components/containers/login';
import React from 'react';

LoginMain.propTypes = {};

function LoginMain(props) {
  return <Login />;
}

export default LoginMain;
